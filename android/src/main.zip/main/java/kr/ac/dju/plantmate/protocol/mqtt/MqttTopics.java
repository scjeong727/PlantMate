package kr.ac.dju.plantmate.protocol.mqtt;

public final class MqttTopics {

    private MqttTopics() {
    }

    public static String sensorTopic(int plantId) {
        return "plant/" + plantId + "/sensor";
    }

    public static String statusTopic(int plantId) {
        return "plant/" + plantId + "/status";
    }

    public static String waterCommandTopic(int plantId) {
        return "plant/" + plantId + "/water/command";
    }
}
