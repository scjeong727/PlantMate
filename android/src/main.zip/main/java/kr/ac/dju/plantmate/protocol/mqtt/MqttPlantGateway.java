package kr.ac.dju.plantmate.protocol.mqtt;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import kr.ac.dju.plantmate.model.MonitorSnapshot;
import kr.ac.dju.plantmate.model.PlantProfile;
import kr.ac.dju.plantmate.protocol.ConnectionConfig;
import kr.ac.dju.plantmate.protocol.PlantGateway;

public class MqttPlantGateway implements PlantGateway {

    private static final String PREFS = "mqtt_plant_repo";
    private static final String KEY_PLANTS = "plants";
    private static final String KEY_SELECTED_PLANT = "selected_plant";
    private static final String KEY_BROKER_HOST = "broker_host";
    private static final String KEY_BROKER_PORT = "broker_port";
    private static final String KEY_BROKER_CLIENT = "broker_client";
    private static final String VIRTUAL_SENSOR_DEVICE = "MQTT sensor topic";
    private static final String VIRTUAL_WATER_DEVICE = "MQTT water command";

    private final SharedPreferences preferences;
    private final MqttManager mqttManager = new MqttManager();
    private final List<String> sensorHistory = new ArrayList<>();
    private final List<String> eventHistory = new ArrayList<>();
    private final List<String> waterHistory = new ArrayList<>();

    private String loginId = "";
    private int selectedSensorPlantId = -1;

    private float lastTemperature;
    private float lastHumidity;
    private int lastSoil;
    private int lastLight;
    private String lastTimestamp = "";
    private String lastEventMessage = "대기 중";

    public MqttPlantGateway(Context context) {
        preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        ensureDefaultPlants();
        mqttManager.setListener(new MqttManager.ManagerListener() {
            @Override
            public void onConnected(boolean reconnect) {
                appendEvent(reconnect ? "MQTT 재연결 완료" : "MQTT 브로커 연결됨");
            }

            @Override
            public void onConnectionLost(String message) {
                appendEvent(message);
            }

            @Override
            public void onMessageReceived(String topic, String payload) {
                handleIncomingMessage(topic, payload);
            }

            @Override
            public void onError(String message) {
                appendEvent(message);
            }
        });
    }

    @Override
    public void connect(ConnectionConfig config) throws Exception {
        if (config.getHost() == null || config.getHost().trim().isEmpty()) {
            throw new IllegalArgumentException("브로커 주소를 입력하세요.");
        }
        saveBrokerConfig(new BrokerConfig(
                config.getHost().trim(),
                config.getPort(),
                config.getClientId() == null || config.getClientId().trim().isEmpty()
                        ? "PlantMate-MQTT"
                        : config.getClientId().trim()
        ));
        awaitAction(callback -> mqttManager.connect(getBrokerConfig(), callback));
    }

    @Override
    public boolean isConnected() {
        return mqttManager.isConnected();
    }

    @Override
    public int login(String loginId, String loginPw) {
        if (loginId == null || loginId.trim().isEmpty() || loginPw == null || loginPw.trim().isEmpty()) {
            throw new IllegalArgumentException("ID와 비밀번호를 입력하세요.");
        }
        this.loginId = loginId.trim();
        appendEvent("MQTT 세션 로그인: " + this.loginId);
        return 1;
    }

    @Override
    public void signup(String loginId, String loginPw) {
        if (loginId == null || loginId.trim().isEmpty() || loginPw == null || loginPw.trim().isEmpty()) {
            throw new IllegalArgumentException("ID와 비밀번호를 입력하세요.");
        }
        appendEvent("MQTT 로컬 사용자 준비 완료: " + loginId.trim());
    }

    @Override
    public List<PlantProfile> loadPlants() {
        return getPlants();
    }

    @Override
    public void addPlant(int userId, PlantProfile plant) {
        upsertPlant(new PlantProfile(
                nextPlantId(),
                userId,
                plant.getName(),
                plant.getType(),
                plant.getTempMin(),
                plant.getTempMax(),
                plant.getHumiMin(),
                plant.getHumiMax(),
                plant.getSoilMin(),
                plant.getSoilMax(),
                plant.getLightMin(),
                plant.getLightMax(),
                ""
        ));
        appendEvent("MQTT 식물 추가 완료");
    }

    @Override
    public void editPlant(int userId, PlantProfile plant) {
        if (plant.getPlantId() <= 0) {
            throw new IllegalArgumentException("수정할 식물을 먼저 선택하세요.");
        }
        upsertPlant(plant);
        appendEvent("MQTT 식물 수정 완료");
    }

    @Override
    public void deletePlant(int userId, int plantId) {
        if (plantId <= 0) {
            throw new IllegalArgumentException("삭제할 식물을 먼저 선택하세요.");
        }
        List<PlantProfile> plants = getPlants();
        List<PlantProfile> updated = new ArrayList<>();
        for (PlantProfile plant : plants) {
            if (plant.getPlantId() != plantId) {
                updated.add(plant);
            }
        }
        savePlants(updated);
        if (selectedPlantId() == plantId) {
            selectPlant(updated.isEmpty() ? -1 : updated.get(0).getPlantId());
        }
        appendEvent("MQTT 식물 삭제 완료");
    }

    @Override
    public MonitorSnapshot loadMonitorSnapshot(int plantId) {
        selectPlant(plantId);
        return new MonitorSnapshot(
                String.format(Locale.KOREA, "T:%.1f H:%.1f S:%d L:%d", lastTemperature, lastHumidity, lastSoil, lastLight),
                lastEventMessage,
                joinLines(sensorHistory, "센서 이력이 없습니다."),
                joinLines(eventHistory, "이벤트 이력이 없습니다.")
        );
    }

    @Override
    public List<String> loadSensorDevices() {
        List<String> items = new ArrayList<>();
        items.add(VIRTUAL_SENSOR_DEVICE);
        return items;
    }

    @Override
    public void setSensorDevice(String path, int plantId) throws Exception {
        requireConnected();
        if (selectedSensorPlantId > 0) {
            unsubscribePlantTopics(selectedSensorPlantId);
        }
        selectedSensorPlantId = plantId;
        selectPlant(plantId);
        awaitAction(callback -> mqttManager.subscribe(MqttTopics.sensorTopic(plantId), 1, callback));
        awaitAction(callback -> mqttManager.subscribe(MqttTopics.statusTopic(plantId), 1, callback));
        appendEvent("MQTT 구독 시작: plant/" + plantId);
    }

    @Override
    public void stopSensorStream() throws Exception {
        if (selectedSensorPlantId <= 0) {
            return;
        }
        unsubscribePlantTopics(selectedSensorPlantId);
        appendEvent("MQTT 구독 중지");
        selectedSensorPlantId = -1;
    }

    @Override
    public List<String> loadWaterDevices() {
        List<String> items = new ArrayList<>();
        items.add(VIRTUAL_WATER_DEVICE);
        return items;
    }

    @Override
    public void setWaterDevice(String path) {
        appendEvent("MQTT 급수 채널 준비 완료");
    }

    @Override
    public void waterPlant(int plantId, int duration) throws Exception {
        requireConnected();
        if (duration <= 0) {
            throw new IllegalArgumentException("급수 시간을 입력하세요.");
        }
        JSONObject payload = new JSONObject();
        try {
            payload.put("duration", duration);
            payload.put("command", "water");
            payload.put("loginId", loginId);
        } catch (JSONException exception) {
            throw new IllegalStateException("급수 payload 생성 실패");
        }
        awaitAction(callback -> mqttManager.publish(MqttTopics.waterCommandTopic(plantId), payload.toString(), callback));
        String line = String.format(Locale.KOREA, "plant/%d | %d초", plantId, duration);
        waterHistory.add(0, line);
        appendEvent("MQTT 급수 명령 발행 완료");
    }

    @Override
    public String loadWaterHistoryText(int plantId) {
        return joinLines(waterHistory, "급수 이력이 없습니다.");
    }

    @Override
    public void close() {
        mqttManager.disconnect();
    }

    private void ensureDefaultPlants() {
        if (!getPlants().isEmpty()) {
            return;
        }
        List<PlantProfile> defaults = new ArrayList<>();
        defaults.add(new PlantProfile(1, 1, "바질", "허브", 18, 27, 40, 70, 35, 65, 300, 900, ""));
        defaults.add(new PlantProfile(2, 1, "몬스테라", "관엽", 20, 30, 45, 75, 30, 55, 200, 700, ""));
        savePlants(defaults);
        selectPlant(1);
    }

    private List<PlantProfile> getPlants() {
        List<PlantProfile> plants = new ArrayList<>();
        String raw = preferences.getString(KEY_PLANTS, "[]");
        try {
            JSONArray jsonArray = new JSONArray(raw);
            for (int i = 0; i < jsonArray.length(); i++) {
                plants.add(parsePlant(jsonArray.getJSONObject(i)));
            }
        } catch (JSONException ignored) {
        }
        return plants;
    }

    private void savePlants(List<PlantProfile> plants) {
        JSONArray jsonArray = new JSONArray();
        for (PlantProfile plant : plants) {
            jsonArray.put(toJson(plant));
        }
        preferences.edit().putString(KEY_PLANTS, jsonArray.toString()).apply();
    }

    private void upsertPlant(PlantProfile plantProfile) {
        List<PlantProfile> plants = getPlants();
        boolean updated = false;
        for (int i = 0; i < plants.size(); i++) {
            if (plants.get(i).getPlantId() == plantProfile.getPlantId()) {
                plants.set(i, plantProfile);
                updated = true;
                break;
            }
        }
        if (!updated) {
            plants.add(plantProfile);
        }
        savePlants(plants);
        selectPlant(plantProfile.getPlantId());
    }

    private BrokerConfig getBrokerConfig() {
        return new BrokerConfig(
                preferences.getString(KEY_BROKER_HOST, "broker.hivemq.com"),
                preferences.getInt(KEY_BROKER_PORT, 1883),
                preferences.getString(KEY_BROKER_CLIENT, "PlantMate-MQTT")
        );
    }

    private void saveBrokerConfig(BrokerConfig config) {
        preferences.edit()
                .putString(KEY_BROKER_HOST, config.getHost())
                .putInt(KEY_BROKER_PORT, config.getPort())
                .putString(KEY_BROKER_CLIENT, config.getClientId())
                .apply();
    }

    private void handleIncomingMessage(String topic, String payload) {
        PlantProfile selectedPlant = getSelectedPlant();
        if (selectedPlant == null) {
            return;
        }
        if (topic.equals(MqttTopics.sensorTopic(selectedPlant.getPlantId()))) {
            MqttSensorPayload sensorPayload = parseSensorPayload(payload);
            if (sensorPayload == null) {
                appendEvent("센서 payload 파싱 실패");
                return;
            }
            lastTemperature = sensorPayload.getTemperature();
            lastHumidity = sensorPayload.getHumidity();
            lastSoil = sensorPayload.getSoilMoisture();
            lastLight = sensorPayload.getLight();
            lastTimestamp = sensorPayload.getTimestamp();
            sensorHistory.add(0, formatSnapshotLine(sensorPayload));
            if (sensorHistory.size() > 20) {
                sensorHistory.remove(sensorHistory.size() - 1);
            }
            return;
        }
        if (topic.equals(MqttTopics.statusTopic(selectedPlant.getPlantId()))) {
            appendEvent(payload);
        }
    }

    private MqttSensorPayload parseSensorPayload(String payload) {
        try {
            JSONObject jsonObject = new JSONObject(payload);
            float temperature = (float) jsonObject.optDouble("temperature", jsonObject.optDouble("temp", 0));
            float humidity = (float) jsonObject.optDouble("humidity", jsonObject.optDouble("humi", 0));
            int soil = jsonObject.optInt("soilMoisture", jsonObject.optInt("soil", 0));
            int light = jsonObject.optInt("light", jsonObject.optInt("lux", 0));
            String timestamp = jsonObject.optString("timestamp", "");
            return new MqttSensorPayload(temperature, humidity, soil, light, timestamp);
        } catch (JSONException exception) {
            return null;
        }
    }

    private String formatSnapshotLine(MqttSensorPayload payload) {
        String prefix = payload.getTimestamp().isEmpty() ? "수신" : payload.getTimestamp();
        return String.format(Locale.KOREA, "%s | T %.1f / H %.1f / S %d / L %d",
                prefix,
                payload.getTemperature(),
                payload.getHumidity(),
                payload.getSoilMoisture(),
                payload.getLight());
    }

    private void appendEvent(String message) {
        lastEventMessage = message;
        eventHistory.add(0, message);
        if (eventHistory.size() > 20) {
            eventHistory.remove(eventHistory.size() - 1);
        }
    }

    private PlantProfile getSelectedPlant() {
        int selectedPlantId = selectedPlantId();
        for (PlantProfile plant : getPlants()) {
            if (plant.getPlantId() == selectedPlantId) {
                return plant;
            }
        }
        List<PlantProfile> plants = getPlants();
        return plants.isEmpty() ? null : plants.get(0);
    }

    private int selectedPlantId() {
        return preferences.getInt(KEY_SELECTED_PLANT, -1);
    }

    private void selectPlant(int plantId) {
        preferences.edit().putInt(KEY_SELECTED_PLANT, plantId).apply();
    }

    private int nextPlantId() {
        int maxId = 0;
        for (PlantProfile plant : getPlants()) {
            if (plant.getPlantId() > maxId) {
                maxId = plant.getPlantId();
            }
        }
        return maxId + 1;
    }

    private JSONObject toJson(PlantProfile plant) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("plantId", plant.getPlantId());
            jsonObject.put("userId", plant.getUserId());
            jsonObject.put("name", plant.getName());
            jsonObject.put("type", plant.getType());
            jsonObject.put("tempMin", plant.getTempMin());
            jsonObject.put("tempMax", plant.getTempMax());
            jsonObject.put("humiMin", plant.getHumiMin());
            jsonObject.put("humiMax", plant.getHumiMax());
            jsonObject.put("soilMin", plant.getSoilMin());
            jsonObject.put("soilMax", plant.getSoilMax());
            jsonObject.put("lightMin", plant.getLightMin());
            jsonObject.put("lightMax", plant.getLightMax());
            jsonObject.put("createdAt", plant.getCreatedAt());
        } catch (JSONException ignored) {
        }
        return jsonObject;
    }

    private PlantProfile parsePlant(JSONObject jsonObject) throws JSONException {
        return new PlantProfile(
                jsonObject.getInt("plantId"),
                jsonObject.optInt("userId", 1),
                jsonObject.getString("name"),
                jsonObject.optString("type", ""),
                jsonObject.optDouble("tempMin", 0),
                jsonObject.optDouble("tempMax", 0),
                jsonObject.optDouble("humiMin", 0),
                jsonObject.optDouble("humiMax", 0),
                jsonObject.optInt("soilMin", 0),
                jsonObject.optInt("soilMax", 0),
                jsonObject.optInt("lightMin", 0),
                jsonObject.optInt("lightMax", 0),
                jsonObject.optString("createdAt", "")
        );
    }

    private String joinLines(List<String> lines, String emptyText) {
        if (lines.isEmpty()) {
            return emptyText;
        }
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            if (i > 0) {
                builder.append('\n');
            }
            builder.append(lines.get(i));
        }
        return builder.toString();
    }

    private void requireConnected() {
        if (!mqttManager.isConnected()) {
            throw new IllegalStateException("먼저 브로커에 연결하세요.");
        }
    }

    private void unsubscribePlantTopics(int plantId) throws Exception {
        awaitAction(callback -> mqttManager.unsubscribe(MqttTopics.sensorTopic(plantId), callback));
        awaitAction(callback -> mqttManager.unsubscribe(MqttTopics.statusTopic(plantId), callback));
    }

    private void awaitAction(ActionRunner runner) throws Exception {
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<String> errorRef = new AtomicReference<>();
        runner.run(new MqttManager.ActionCallback() {
            @Override
            public void onSuccess() {
                latch.countDown();
            }

            @Override
            public void onError(String message) {
                errorRef.set(message);
                latch.countDown();
            }
        });
        if (!latch.await(10, TimeUnit.SECONDS)) {
            throw new IOException("MQTT 응답 대기 시간 초과");
        }
        if (errorRef.get() != null) {
            throw new IOException(errorRef.get());
        }
    }

    private interface ActionRunner {
        void run(MqttManager.ActionCallback callback) throws Exception;
    }
}
