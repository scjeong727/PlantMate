package kr.ac.dju.plantmate.model;

public class SessionState {

    private final boolean connected;
    private final boolean loggedIn;
    private final int userId;
    private final String loginId;

    public SessionState(boolean connected, boolean loggedIn, int userId, String loginId) {
        this.connected = connected;
        this.loggedIn = loggedIn;
        this.userId = userId;
        this.loginId = loginId;
    }

    public boolean isConnected() {
        return connected;
    }

    public boolean isLoggedIn() {
        return loggedIn;
    }

    public int getUserId() {
        return userId;
    }

    public String getLoginId() {
        return loginId;
    }
}
